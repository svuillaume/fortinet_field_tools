var START = "https://video.fortinet.com/products/lacework-forticnapp";
var HIDE_CSS = "html:not(.fl-ready)::before{content:'';position:fixed;inset:0;background:#0b0d12;z-index:2147483647}html:not(.fl-ready){background:#0b0d12 !important}";

function hide(tabId) { chrome.scripting.insertCSS({ target: { tabId: tabId }, css: HIDE_CSS }).catch(function () {}); }

function inject(tabId) {
  chrome.storage.local.get({ videos: [] }, function (data) {
    var videos = Array.isArray(data.videos) ? data.videos : [];
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: "MAIN",
      func: function (v) { window.__FL_VIDEOS = v; },
      args: [videos]
    }, function () {
      chrome.scripting.executeScript({ target: { tabId: tabId }, files: ["loop.js"], world: "MAIN" });
    });
  });
}

function startInTab(tabId) {
  hide(tabId);
  if (tabId == null) return;
  chrome.tabs.get(tabId, function (t) {
    if (t && t.url && t.url.indexOf("https://video.fortinet.com/") === 0) { inject(tabId); return; }
    chrome.tabs.update(tabId, { url: START });
    var cssInjected = false;
    function onUpdated(id, info) {
      if (id !== tabId) return;
      if (!cssInjected && (info.status === "loading" || info.status === "complete")) {
        cssInjected = true;
        hide(tabId);
      }
      if (info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        inject(tabId);
      }
    }
    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

function startNewTab() {
  chrome.tabs.create({ url: START }, function (t) {
    var cssInjected = false;
    function onUpdated(id, info) {
      if (id !== t.id) return;
      if (!cssInjected && (info.status === "loading" || info.status === "complete")) {
        cssInjected = true;
        hide(t.id);
      }
      if (info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        inject(t.id);
      }
    }
    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

// Clicking the extension icon opens the FortiBoothDemo settings page (not the loop)
chrome.action.onClicked.addListener(function () {
  chrome.runtime.openOptionsPage();
});

// Settings page asks us to start the loop
chrome.runtime.onMessage.addListener(function (msg, sender, send) {
  if (msg && msg.type === "startLoop") { startNewTab(); send({ ok: true }); return true; }
});
