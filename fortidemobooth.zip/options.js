(function () {
  var DEFAULTS = [];

  var state = [];
  var $ = function (id) { return document.getElementById(id); };

  function load() {
    chrome.storage.local.get({ videos: [] }, function (d) {
      state = (Array.isArray(d.videos) && d.videos.length) ? d.videos.slice() : DEFAULTS.slice();
      render();
    });
  }

  function save(cb) {
    // strip url field from stored copy (loop only needs id/title/text/why/start) — but keep it for the editor
    chrome.storage.local.set({ videos: state }, function () { if (cb) cb(); });
  }

  function esc(s) { return (s || "").replace(/[&<>"]/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]; }); }

  function render() {
    var list = $("list");
    list.innerHTML = "";
    if (state.length === 0) { list.innerHTML = "<li class=\"empty\">No videos yet. Paste a Fortinet video URL above and click <b>Fetch &amp; add</b>.</li>"; refreshLaunch(); return; }
    state.forEach(function (v, i) {
      var li = document.createElement("li");
      li.className = "item";
      li.innerHTML =
        '<div class="top">' +
          '<div><div class="t">' + esc(v.title || "(no title)") + ' <span class="pill">' + ((v.platform || "vimeo").toUpperCase()) + '</span></div><div class="u">' + esc(v.url || ((v.platform || "vimeo") + " id " + v.id)) + '</div></div>' +
          '<div class="ctl">' +
            '<button class="ghost" data-op="up" ' + (i === 0 ? 'disabled' : '') + '>▲</button>' +
            '<button class="ghost" data-op="down" ' + (i === state.length - 1 ? 'disabled' : '') + '>▼</button>' +
            '<button class="ghost" data-op="del">Delete</button>' +
          '</div>' +
        '</div>' +
        '<label>Slide title</label>' +
        '<input data-f="title" value="' + esc(v.title) + '">' +
        '<label>What this demo shows (one or two sentences)</label>' +
        '<textarea data-f="text">' + esc(v.text) + '</textarea>' +
        '<label>Why it matters in the public cloud</label>' +
        '<textarea data-f="why">' + esc(v.why) + '</textarea>' +
        '<label>Start seconds (optional, skips the baked-in intro)</label>' +
        '<input data-f="start" placeholder="e.g. 74" value="' + esc(v.start != null ? v.start : "") + '">';
      li.querySelectorAll("[data-f]").forEach(function (el) {
        el.addEventListener("input", function () {
          var key = el.getAttribute("data-f");
          var val = el.value;
          if (key === "start") val = val.trim() === "" ? undefined : Number(val);
          if (val === undefined) delete state[i][key]; else state[i][key] = val;
        });
      });
      li.querySelector('[data-op="up"]').addEventListener("click", function () { if (i > 0) { var t = state[i - 1]; state[i - 1] = state[i]; state[i] = t; render(); } });
      li.querySelector('[data-op="down"]').addEventListener("click", function () { if (i < state.length - 1) { var t = state[i + 1]; state[i + 1] = state[i]; state[i] = t; render(); } });
      li.querySelector('[data-op="del"]').addEventListener("click", function () { if (confirm("Remove this video from the loop?")) { state.splice(i, 1); render(); } });
      list.appendChild(li);
    });
    refreshLaunch();
  }

  function titleize(slug) {
    return slug.replace(/-/g, " ").replace(/\b\w/g, function (c) { return c.toUpperCase(); })
      .replace(/\bForticnapp\b/g, "FortiCNAPP").replace(/\bAi\b/g, "AI");
  }

  async function fetchPage(url) {
    try {
      var r = await fetch(url, { credentials: "omit" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      var t = await r.text();
      var vm = t.match(/player\.vimeo\.com\/video\/(\d+)/) || t.match(/vimeo\.com\/video\/(\d+)/);
      var ym = t.match(/youtube(?:-nocookie)?\.com\/embed\/([A-Za-z0-9_-]{10,15})/) || t.match(/youtu\.be\/([A-Za-z0-9_-]{10,15})/);
      var tm = t.match(/<title>([^<]+)<\/title>/i);
      var dm = t.match(/<meta[^>]+name="description"[^>]+content="([^"]+)"/i)
            || t.match(/<meta[^>]+property="og:description"[^>]+content="([^"]+)"/i);
      var raw = tm ? tm[1].trim() : "";
      var title = raw.split(" - ")[0].replace(/^Lacework\s+/i, "");
      if (!title) {
        var slug = url.replace(/\/$/, "").split("/").pop().replace(/^forticnapp-/, "").replace(/^lacework-forticnapp-/, "");
        title = titleize(slug);
      }
      var platform = vm ? "vimeo" : (ym ? "youtube" : null);
      var id = vm ? Number(vm[1]) : (ym ? ym[1] : null);
      return { id: id, platform: platform, title: title, description: dm ? dm[1].trim() : "" };
    } catch (e) {
      return { error: String(e.message || e) };
    }
  }

  $("addBtn").addEventListener("click", async function () {
    var urlEl = $("newUrl"); var msg = $("addMsg");
    var url = urlEl.value.trim();
    msg.textContent = "";
    if (!/^https:\/\/video\.fortinet\.com\//.test(url)) {
      msg.className = "err"; msg.textContent = "URL must start with https://video.fortinet.com/"; return;
    }
    $("addBtn").disabled = true; msg.className = ""; msg.textContent = "Fetching...";
    var info = await fetchPage(url);
    $("addBtn").disabled = false;
    if (info.error || !info.id) {
      msg.className = "err"; msg.textContent = info.error ? ("Could not read the page: " + info.error) : "Could not find a Vimeo or YouTube video on that page."; return;
    }
    var topic = info.title.toLowerCase();
    var text = info.description && info.description.length > 20 ? info.description
      : "A FortiCNAPP demo covering " + info.title + ".";
    var why = /container/.test(topic) ? "Containers are how most cloud applications ship. If the building blocks are weak, every copy running in the cloud inherits the weakness."
            : /alert|remed|sum/.test(topic) ? "Cloud environments produce thousands of alerts. Fast, clear answers help a small team keep up."
            : /risk|unified|dash/.test(topic) ? "Public cloud spreads across AWS, Azure and Google Cloud. One ranked view of real risk keeps teams focused on what matters."
            : /timeline|assist/.test(topic) ? "In a cloud breach, minutes matter. A clear timeline and an AI assistant get a responder to the right answer without digging through separate logs."
            : "This demo shows capabilities that matter when running security across the public cloud.";
    state.push({ id: info.id, platform: info.platform, url: url, title: info.title, text: text, why: why });
    render();
    urlEl.value = "";
    msg.className = "ok"; msg.textContent = 'Added "' + info.title + '" — edit the slide below if needed, then Save.';
  });

  $("saveBtn").addEventListener("click", function () {
    save(function () { var m = $("saveMsg"); m.className = "ok"; m.textContent = "Saved."; setTimeout(function () { m.textContent = ""; }, 2000); });
  });
  $("clearBtn").addEventListener("click", function () {
    if (!confirm("Remove all videos from the playlist?")) return;
    state = []; render();
    chrome.storage.local.set({ videos: [] });
    var m = $("saveMsg"); m.className = "ok"; m.textContent = "Cleared."; setTimeout(function () { m.textContent = ""; }, 2500);
  });


  function refreshLaunch() {
    var btn = $("launchBtn"); if (!btn) return;
    var n = state.length;
    btn.disabled = n === 0;
    $("launchHint").textContent = n === 0 ? "Add at least one video first." : "Plays " + n + " demo" + (n === 1 ? "" : "s") + " in a new tab, back to back.";
  }
  $("launchBtn").addEventListener("click", function () {
    // Save first so the loop reads what's on screen now
    save(function () {
      chrome.runtime.sendMessage({ type: "startLoop" }, function () { /* ignore */ });
      var m = $("launchHint"); m.textContent = "Launched in a new tab. You can close this one.";
    });
  });


  function toJson() {
    return JSON.stringify({
      format: "fortiboothdemo-playlist",
      version: 1,
      exportedAt: new Date().toISOString(),
      videos: state
    }, null, 2);
  }
  $("exportBtn").addEventListener("click", function () {
    var blob = new Blob([toJson()], { type: "application/json" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    var stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    a.download = "fortiboothdemo-playlist-" + stamp + ".json";
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(a.href);
    var m = $("saveMsg"); m.className = "ok"; m.textContent = "Exported."; setTimeout(function () { m.textContent = ""; }, 2500);
  });
  $("importBtn").addEventListener("click", function () { $("importFile").click(); });
  $("importFile").addEventListener("change", function (e) {
    var f = e.target.files && e.target.files[0]; if (!f) return;
    var r = new FileReader();
    r.onload = function () {
      var txt = r.result; var parsed;
      try { parsed = JSON.parse(txt); } catch (err) {
        var m = $("saveMsg"); m.className = "err"; m.textContent = "Not valid JSON: " + err.message; return;
      }
      var vids = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.videos) ? parsed.videos : null);
      if (!vids) { var m = $("saveMsg"); m.className = "err"; m.textContent = "File does not contain a videos list."; return; }
      // Keep only well-formed entries
      var clean = vids.filter(function (v) { return v && v.id && v.title; }).map(function (v) {
        var pid = v.platform === "youtube" ? String(v.id) : Number(v.id);
        return { id: pid, platform: v.platform || "vimeo", url: v.url || "", title: v.title, text: v.text || "", why: v.why || "", start: (v.start != null ? Number(v.start) : undefined) };
      });
      if (!clean.length) { var m = $("saveMsg"); m.className = "err"; m.textContent = "No usable entries in the file."; return; }
      if (!confirm("Replace the current playlist with " + clean.length + " video(s) from the file?")) return;
      state = clean; render();
      save(function () { var m = $("saveMsg"); m.className = "ok"; m.textContent = "Imported and saved."; setTimeout(function () { m.textContent = ""; }, 2500); });
    };
    r.readAsText(f);
    e.target.value = "";
  });

  load();
})();
