(function () {
  if (!/(^|\.)video\.fortinet\.com$/.test(location.hostname)) {
    alert("Open any page on video.fortinet.com first, then run this again.");
    return;
  }
  var HOLD = window.FL_HOLD || 5000;   // how long each divider card stays up (ms)
  var FADE = 800;                      // card fade in/out (ms)

  // ---- Edit this list: Vimeo ID, title, plain-language description ----
  var DEFAULT_V = [];
  var V = (Array.isArray(window.__FL_VIDEOS) && window.__FL_VIDEOS.length) ? window.__FL_VIDEOS : DEFAULT_V;

  // ---------------------------------------------------------------------

  var N = V.length, frames = [], slotVideo = [-1, -1], active = -1, idx = 0, token = 0;
  var state = "idle", paused = false, gotPlay = false, ctlTimer = null;
  var ccOn = window.FL_CC !== false;       // captions on by default where a caption track exists
  var muted = window.FL_MUTE === true;    // sound on by default; press M or use the button to mute
  var vol = null, mut = null, trk = undefined, needClick = false, hudTimer = null;
  var ending = false, skipping = false, lastSec = 0, pausedNow = null, userPaused = false, holdCard = false, pending = null, pauseBtn = null, cdTimer = null;
  window.__fl_log = [];

  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }

  var css = el("style");
  css.textContent =
    ".fl-root{position:fixed;inset:0;background:#000;color:#fff;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}" +
    ".fl-root iframe{position:absolute;inset:0;width:100%;height:100%;border:0;background:#000}" +
    ".fl-card{position:absolute;inset:0;z-index:10;overflow:hidden;display:flex;flex-direction:column;justify-content:center;padding:0 0 0 7vw;" +
      "background:radial-gradient(ellipse at 18% 8%,rgba(150,160,190,.55) 0%,rgba(150,160,190,0) 38%),radial-gradient(ellipse at 40% 90%,rgba(255,170,90,.28) 0%,rgba(255,170,90,0) 40%),radial-gradient(ellipse at 85% 10%,rgba(60,120,255,.22) 0%,rgba(60,120,255,0) 40%),#f7f9fd;" +
      "color:#0f1240;opacity:0;pointer-events:none;transition:opacity " + FADE + "ms ease}" +
    ".fl-card.show{opacity:1}" +
    ".fl-card>.fl-col{position:relative;z-index:2;width:84vw;max-width:84vw}" +
    ".fl-mock{position:absolute;z-index:1;right:-5vw;top:14vh;width:46vw;height:96vh;border-radius:26px 0 0 0;background:#fff;box-shadow:0 20px 70px rgba(15,18,64,.18);display:flex;overflow:hidden;filter:blur(1.2px);opacity:.92}" +
    ".fl-mock .sb{width:24%;background:#07094d;padding:5% 4%;display:flex;flex-direction:column;gap:2.4vh}" +
    ".fl-mock .sb i{display:block;height:1.6vh;border-radius:4px;background:rgba(255,255,255,.28)}" +
    ".fl-mock .sb i.on{background:#2f5bff;height:3.4vh}" +
    ".fl-mock .mn{flex:1;padding:4% 4%;display:flex;flex-direction:column;gap:3vh}" +
    ".fl-mock .mn b{display:block;height:2.4vh;width:28%;border-radius:4px;background:#1b1f3b}" +
    ".fl-mock .row{display:flex;gap:3%}" +
    ".fl-mock .box{flex:1;height:30vh;border:1px solid #e3e7f1;border-radius:10px;display:flex;align-items:center;justify-content:center}" +
    ".fl-mock .don{width:15vh;height:15vh;border-radius:50%;background:conic-gradient(#b3261e 0 9%,#ef7d73 9% 29%,#f2b042 29% 55%,#e5cc4a 55% 69%,#cfd6e6 69% 100%);-webkit-mask:radial-gradient(circle,transparent 52%,#000 53%);mask:radial-gradient(circle,transparent 52%,#000 53%)}" +
    ".fl-mock .wide{height:22vh;border:1px solid #e3e7f1;border-radius:10px}" +
    ".fl-bar{display:none}" +
    ".fl-kicker{font-size:min(1.1vw,2.2vh);letter-spacing:.18em;text-transform:uppercase;color:#4a5170;font-weight:700}" +
    ".fl-title{font-size:min(4.2vw,7.2vh);font-weight:800;line-height:1.08;margin:1.2vh 0 2vh;color:#0f1240}" +
    ".fl-text{font-size:min(1.55vw,3.1vh);line-height:1.35;font-weight:700;color:#1b1f3b}" +
    ".fl-why{margin-top:2.4vh;padding-left:18px;border-left:6px solid #3fb6d9;max-width:70ch;font-size:min(1.2vw,2.5vh);line-height:1.4;color:#2c3355;font-weight:500}" +
    ".fl-why b{color:#0f1240;font-size:.85em;letter-spacing:.08em;text-transform:uppercase}" +
    ".fl-count{margin-top:3.6vh;font-size:min(2.8vw,5.4vh);font-weight:600;line-height:1.1;color:#0f1240}" +
    ".fl-count span{font-weight:800;margin-left:.25em;font-variant-numeric:tabular-nums}" +
    ".fl-prog{margin-top:1.6vh;height:clamp(10px,1.6vh,18px);width:min(30vw,420px);border-radius:12px;background:#07094d;overflow:hidden}" +
    ".fl-prog div{height:100%;width:0;border-radius:12px;background:linear-gradient(90deg,#62cbe0,#3c8ee6);transition:width .25s linear}" +
    ".fl-hint{margin-top:1.6vh;font-size:min(.95vw,1.9vh);color:#5b6384}" +
    ".fl-dots{display:flex;gap:12px;margin-top:2.4vh}" +
    ".fl-dot{width:12px;height:12px;border-radius:50%;background:#c5cbe0}" +
    ".fl-dot.on{background:#07094d}" +
    ".fl-hud{position:absolute;left:18px;bottom:18px;z-index:25;max-width:80vw;background:rgba(15,17,21,.9);color:#e8eaf0;border:1px solid #3a4050;border-radius:8px;padding:10px 16px;font-size:15px;opacity:0;transition:opacity .4s;pointer-events:none}" +
    ".fl-hud.show{opacity:1}" +
    ".fl-hud.bad{background:#da291c;border-color:#da291c;color:#fff;font-size:20px;font-weight:600;left:50%;transform:translateX(-50%);bottom:12vh;padding:16px 28px}" +
    ".fl-cover{position:absolute;inset:0;z-index:5;background:#000;opacity:0;pointer-events:none;transition:opacity .35s ease}" +
    ".fl-cover.on{opacity:1}" +
    ".fl-strip{position:absolute;top:0;left:0;right:0;height:12vh;z-index:15}" +
    ".fl-ctl{position:absolute;left:50%;top:18px;transform:translateX(-50%);z-index:20;display:flex;gap:8px;opacity:0;transition:opacity .3s;pointer-events:none}" +
    ".fl-ctl.vis{opacity:1;pointer-events:auto}" +
    ".fl-ctl button{background:rgba(20,22,28,.88);color:#fff;border:1px solid #3a4050;border-radius:6px;padding:8px 14px;font-size:14px;cursor:pointer}" +
    ".fl-start{position:absolute;inset:0;z-index:30;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;background:#0b0d12;text-align:center;padding:24px}" +
    ".fl-start button{background:#da291c;color:#fff;border:0;border-radius:8px;padding:16px 34px;font-size:20px;cursor:pointer}" +
    ".fl-start div{color:#b9c0cc;max-width:560px}";
  document.head.appendChild(css);

  document.body.innerHTML = "";
  document.body.style.cssText = "margin:0;background:#000;overflow:hidden";
  var root = el("div", "fl-root");
  document.body.appendChild(root);
  document.documentElement.classList.add("fl-ready");   // tells the extension's hide overlay to lift

  function platOf(v) { return v && v.platform === "youtube" ? "youtube" : "vimeo"; }
  function url(k) {
    var v = V[k];
    if (platOf(v) === "youtube") {
      // enablejsapi + origin + cc_load_policy makes captions appear and lets us control via postMessage
      return "https://www.youtube.com/embed/" + v.id + "?enablejsapi=1&autoplay=1&rel=0&modestbranding=1&playsinline=1&cc_load_policy=1&iv_load_policy=3&origin=" + encodeURIComponent(location.origin) + (v.start ? "&start=" + v.start : "");
    }
    return "https://player.vimeo.com/video/" + v.id + "?title=0&byline=0&portrait=0&dnt=1" + (v.start ? "#t=" + v.start + "s" : "");
  }
  function post(s, m, v) {
    var f = frames[s];
    if (!f || !f.contentWindow) return;
    var cur = slotVideo[s];
    var plat = cur >= 0 ? platOf(V[cur]) : "vimeo";
    if (plat === "youtube") {
      var cmd = ytCommand(m, v);
      if (cmd) f.contentWindow.postMessage(JSON.stringify(cmd), "*");
    } else {
      f.contentWindow.postMessage(JSON.stringify(v === undefined ? { method: m } : { method: m, value: v }), "*");
    }
  }
  // Translate the loop's Vimeo-style command set into YouTube IFrame API postMessages.
  function ytCommand(m, v) {
    switch (m) {
      case "play": return { event: "command", func: "playVideo", args: [] };
      case "pause": return { event: "command", func: "pauseVideo", args: [] };
      case "setMuted": return v ? { event: "command", func: "mute", args: [] } : { event: "command", func: "unMute", args: [] };
      case "setVolume": return { event: "command", func: "setVolume", args: [Math.round((v || 0) * 100)] };
      case "setCurrentTime": return { event: "command", func: "seekTo", args: [v, true] };
      case "setPlaybackRate": return { event: "command", func: "setPlaybackbackRate", args: [v] };
      case "enableTextTrack": return { event: "command", func: "setOption", args: ["captions", "track", { languageCode: "en" }] };
      case "disableTextTrack": return { event: "command", func: "unloadModule", args: ["captions"] };
      case "addEventListener": return { event: "listening", id: null };
      default: return null;
    }
  }
  function sub(s) {
    var cur = slotVideo[s];
    var plat = cur >= 0 ? platOf(V[cur]) : "vimeo";
    if (plat === "youtube") {
      // one listening message is enough to start receiving onStateChange and infoDelivery
      var f = frames[s];
      if (f && f.contentWindow) f.contentWindow.postMessage(JSON.stringify({ event: "listening" }), "*");
    } else {
      ["play", "pause", "finish", "error", "playProgress", "timeupdate"].forEach(function (e) { post(s, "addEventListener", e); });
    }
  }
  function loadSlot(s, k) { slotVideo[s] = k; frames[s].src = url(k); }

  function normalLoad(s) { frames[s].onload = function () { sub(s); setTimeout(function () { sub(s); }, 1500); }; }
  // Reload this slot's player (optionally seeking) and play: last-resort recovery when play/resume is ignored
  function hardReload(s, seek) {
    window.__fl_log.push("hardReload " + s + " @" + seek);
    var k = slotVideo[s];
    frames[s].onload = function () {
      normalLoad(s);
      sub(s);
      setTimeout(function () { sub(s); post(s, "setMuted", muted); post(s, "setVolume", muted ? 0 : 1); if (seek > 1) post(s, "setCurrentTime", seek); post(s, "play"); }, 1200);
    };
    frames[s].src = url(k);
  }
  [0, 1].forEach(function (s) {
    var f = el("iframe");
    f.allow = "autoplay; fullscreen; picture-in-picture";
    f.allowFullscreen = true;
    f.style.zIndex = 1;
    f.onload = function () { sub(s); setTimeout(function () { sub(s); }, 1500); };
    frames.push(f);
    root.appendChild(f);
  });

  var cover = el("div", "fl-cover");
  root.appendChild(cover);
  var hud = el("div", "fl-hud");
  var catcher = el("div");
  catcher.style.cssText = "position:absolute;inset:0;z-index:24;display:none;cursor:pointer";
  function setNeed(v) { needClick = v; catcher.style.display = v ? "block" : "none"; }
  var card = el("div", "fl-card");
  var cK = el("div", "fl-kicker"), cT = el("div", "fl-title"), cX = el("div", "fl-text"), cW = el("div", "fl-why"), cC = el("div", "fl-count"), cD = el("div", "fl-dots"), cH = el("div", "fl-hint", "Pause / Resume: use the buttons at the top or press Space. Arrow keys skip.");
  var cP = el("div", "fl-prog"), cF = el("div");
  cP.appendChild(cF);
  var col = el("div", "fl-col");
  col.appendChild(cK); col.appendChild(cT); col.appendChild(cX); col.appendChild(cW); col.appendChild(cC); col.appendChild(cP); col.appendChild(cD); col.appendChild(cH);
  card.appendChild(col);
  root.appendChild(card);
  root.appendChild(catcher);
  root.appendChild(hud);

  function fillCard(k) {
    cK.textContent = "FortiCNAPP · Demo " + (k + 1) + " of " + N;
    cT.textContent = V[k].title;
    cX.textContent = V[k].text;
    cW.innerHTML = "<b>Why it matters in the public cloud</b>";
    cW.appendChild(document.createElement("br"));
    cW.appendChild(document.createTextNode(V[k].why));
    cD.innerHTML = "";
    for (var j = 0; j < N; j++) cD.appendChild(el("div", "fl-dot" + (j === k ? " on" : "")));
  }

  function goTo(k) {
    k = ((k % N) + N) % N;
    idx = k;
    var my = ++token;
    userPaused = false; ending = false;
    if (state === "playing" && active >= 0) post(active, "pause");   // stop the old video before the card
    state = "card";
    holdCard = false; pending = null;
    if (pauseBtn) pauseBtn.textContent = "Pause";
    setNeed(false);
    clearTimeout(ctlTimer);
    ctl.classList.add("vis");            // controls stay visible on title cards
    window.__fl_log.push("card " + k);
    fillCard(k);
    cF.style.transition = "none"; cF.style.width = "0%"; void cF.offsetWidth; cF.style.transition = "";
    card.classList.add("show");
    // Single visible player: once the card fully covers the screen, load the next demo into it.
    // (Hidden preloaded players were not starting reliably in Chrome, so every demo now follows the first demo's path.)
    setTimeout(function () { if (my === token) { post(0, "pause"); loadSlot(0, k); } }, FADE + 50);
    // "Demo starts in N seconds" countdown
    clearInterval(cdTimer);
    var deadline = Date.now() + FADE + HOLD;
    var total = FADE + HOLD;
    function tick() {
      if (holdCard) { cC.textContent = "Held \u2014 press Resume to start the demo"; return; }
      var ms = Math.max(0, deadline - Date.now());
      var r = Math.ceil(ms / 1000);
      cC.innerHTML = "Demo starts in <span>" + (r < 10 ? "00:0" : "00:") + r + "</span>";
      cF.style.width = Math.min(100, Math.round((1 - ms / total) * 100)) + "%";
    }
    tick();
    cdTimer = setInterval(tick, 250);
    setTimeout(function () { startDemo(k, my); }, FADE + HOLD);
  }

  function startDemo(k, my) {
    if (my !== token) return;
    if (holdCard) { pending = function () { startDemo(k, my); }; return; }
    clearInterval(cdTimer);
    cC.textContent = "Starting\u2026"; cF.style.width = "100%";
    var s = 0, o = 1;
    if (slotVideo[0] !== k) loadSlot(0, k);
    active = s;
    cover.classList.remove("on"); skipping = false;
    frames[s].style.zIndex = 2;
    frames[o].style.zIndex = 1;
    post(o, "pause");
    state = "playing"; paused = false; userPaused = false; gotPlay = false;
    window.__fl_log.push("play " + k);
    vol = null; mut = null; trk = undefined; setNeed(false);
    hud.className = "fl-hud";
    post(s, "setMuted", muted);
    post(s, "setVolume", muted ? 0 : 1);
    if (!V[k].start) post(s, "setCurrentTime", 0);
    post(s, "play");
    // retry: messages sent before the player is ready are dropped, so re-subscribe and re-send play until it starts
    [700, 1500, 2300].forEach(function (ms) { setTimeout(function () { if (my === token && s === active && !gotPlay && !paused) { sub(s); post(s, "setMuted", muted); post(s, "play"); } }, ms); });
    // last resort: reload this player and play again
    setTimeout(function () { if (my === token && s === active && !gotPlay) { window.__fl_log.push("reload " + k); hardReload(s, 0); } }, 5500);
    card.classList.remove("show");
    clearTimeout(ctlTimer);
    ctlTimer = setTimeout(function () { ctl.classList.remove("vis"); }, 4000);   // hide again shortly after the video starts
    [1200, 3500].forEach(function (ms) { setTimeout(function () { if (my === token && s === active) { if (ccOn) post(s, "getTextTracks"); post(s, "getVolume"); post(s, "getMuted"); } }, ms); });
    setTimeout(function () { if (my === token) report(); }, 4500);
    setTimeout(function () { if (my === token && !gotPlay) { setNeed(true); showHud("Playback was blocked by the browser. Click anywhere to start.", true); } }, 3000);
    setTimeout(function () { if (my === token && !gotPlay && !needClick) goTo(k + 1); }, 15000);
  }

  function showHud(msg, bad, ms) {
    hud.textContent = msg;
    hud.className = "fl-hud show" + (bad ? " bad" : "");
    clearTimeout(hudTimer);
    if (!bad) hudTimer = setTimeout(function () { hud.className = "fl-hud"; }, ms || 8000);
  }
  function report() {
    if (state !== "playing") return;
    var m = [];
    if ((mut === true || vol === 0) && !muted) {
      setNeed(true);
      showHud("Sound is blocked by the browser. Click anywhere to turn it on.", true);
      return;
    }
    m.push(muted ? "Sound: off (press M)" : "Sound: on");
    if (trk && trk.length) m.push("Captions: " + (trk.some(function (t) { return t.mode === "showing"; }) ? "on" : "available (press C)"));
    else if (trk) m.push("Captions: none published for this video");
    showHud(m.join("   |   "), false);
  }
  function end() {
    if (state !== "playing") return;
    if (ending) return;
    ending = true;
    window.__fl_log.push("end " + idx);
    // let the final syllable breathe, then fade to black, then advance
    setTimeout(function () { cover.classList.add("on"); }, 450);
    setTimeout(function () {
      ending = false;
      cover.classList.remove("on");
      goTo(idx + 1);
    }, 1200);
  }

  window.addEventListener("message", function (e) {
    var isVimeo = /vimeo\.com$/.test(e.origin);
    var isYt = /^https?:\/\/(www\.)?youtube(-nocookie)?\.com$/.test(e.origin);
    if (!isVimeo && !isYt) return;
    var s = -1;
    for (var j = 0; j < 2; j++) if (frames[j].contentWindow === e.source) s = j;
    if (s < 0) return;
    if (isYt) {
      // Translate YouTube events to the Vimeo-shaped events the handler below expects
      try {
        var yd = e.data; if (typeof yd === "string") yd = JSON.parse(yd);
        if (!yd) return;
        if (yd.event === "onReady") { sub(s); return; }
        if (yd.event === "onStateChange" || (yd.event === "infoDelivery" && yd.info && typeof yd.info.playerState !== "undefined")) {
          var st = yd.info && typeof yd.info.playerState !== "undefined" ? yd.info.playerState : yd.info;
          if (st === 1) e = { origin: "vimeo", source: e.source, data: { event: "play", data: { percent: 0 } } };
          else if (st === 2) e = { origin: "vimeo", source: e.source, data: { event: "pause", data: { percent: 0 } } };
          else if (st === 0) e = { origin: "vimeo", source: e.source, data: { event: "finish" } };
          else return;
        } else if (yd.event === "infoDelivery" && yd.info && typeof yd.info.currentTime === "number" && typeof yd.info.duration === "number" && yd.info.duration > 0) {
          var pct = yd.info.currentTime / yd.info.duration;
          e = { origin: "vimeo", source: e.source, data: { event: "timeupdate", data: { seconds: yd.info.currentTime, percent: pct, duration: yd.info.duration } } };
        } else if (yd.event === "onError") {
          e = { origin: "vimeo", source: e.source, data: { event: "error", data: { message: "YouTube error " + yd.info } } };
        } else return;
      } catch (x) { return; }
    }
    var d = e.data;
    if (typeof d === "string") { try { d = JSON.parse(d); } catch (x) { return; } }
    if (!d) return;
    if (d.event === "ready") { sub(s); return; }
    if (d.method === "getVolume" && s === active) { vol = d.value; return; }
    if (d.method === "getMuted" && s === active) { mut = d.value; return; }
    if (d.method === "getPaused" && s === active) { pausedNow = d.value; return; }
    if (d.method === "getTextTracks") {
      if (s === active) trk = d.value || [];
      if (s === active && ccOn && d.value && d.value.length) {
        var t = d.value[0];
        for (var q = 0; q < d.value.length; q++) if (/^en/.test(d.value[q].language)) { t = d.value[q]; break; }
        if (t.mode !== "showing") post(s, "enableTextTrack", { language: t.language, kind: t.kind });
      }
      return;
    }
    if (s !== active) return;
    var pct = d.data && d.data.percent;
    if (d.data && typeof d.data.seconds === "number") {
      lastSec = d.data.seconds;
      var sk = V[idx] && V[idx].skip;
      if (sk && s === active && !skipping) {
        for (var si = 0; si < sk.length; si++) {
          var r = sk[si];
          // trigger slightly before the mark so the cover fades in before any skipped frame flashes
          if (lastSec >= r[0] - 0.6 && lastSec < r[1] - 0.3) {
            skipping = true;
            window.__fl_log.push("skip " + r[0] + "->" + r[1]);
            cover.classList.add("on");
            var tgt = r[1];
            setTimeout(function () { post(s, "setCurrentTime", tgt); }, 150);
            // reveal only once playback is actually past the skip target; retry seek if needed
            var tries = 0, iv = setInterval(function () {
              tries++;
              if (lastSec >= tgt - 0.2) { clearInterval(iv); cover.classList.remove("on"); skipping = false; }
              else if (tries % 4 === 0) { post(s, "setCurrentTime", tgt); post(s, "play"); }
              if (tries > 40) { clearInterval(iv); cover.classList.remove("on"); skipping = false; }
            }, 150);
            break;
          }
        }
      }
    }
    if (d.event === "play") { gotPlay = true; paused = false; userPaused = false; if (pauseBtn) pauseBtn.textContent = "Pause"; }
    else if (d.event === "pause") { paused = true; if (pct >= 0.999) end(); else if (state === "playing") { userPaused = true; if (pauseBtn) pauseBtn.textContent = "Resume"; } }
    else if (d.event === "playProgress" || d.event === "timeupdate") { if (pct >= 0.9995) end(); }
    else if (d.event === "finish") end();
    else if (d.event === "error") { window.__fl_log.push("error " + JSON.stringify(d.data || {})); showHud("Player error: " + ((d.data && (d.data.message || d.data.name)) || "unknown") + " - skipping", true); setTimeout(end, 2500); }
  });

  // Controls: appear when the mouse is near the top edge. Keys: arrows = prev/next, space = pause.
  catcher.addEventListener("click", function () {
    if (state !== "playing") { setNeed(false); return; }
    setNeed(false); muted = false;
    post(active, "setMuted", false); post(active, "setVolume", 1); post(active, "play");
    soundBtn.textContent = "Sound: On";
    hud.className = "fl-hud";
  });
  var strip = el("div", "fl-strip");
  var ctl = el("div", "fl-ctl");
  function btn(t, f) { var b = el("button", null, t); b.onclick = function () { b.blur(); f(); }; ctl.appendChild(b); }
  function toggleFs() {
    if (document.fullscreenElement) document.exitFullscreen();
    else if (root.requestFullscreen) root.requestFullscreen().catch(function () {});
  }
  function setSound() { post(active, "setMuted", muted); post(active, "setVolume", muted ? 0 : 1); soundBtn.textContent = muted ? "Sound: Off" : "Sound: On"; }
  function toggleSound() { muted = !muted; setSound(); showHud(muted ? "Sound off" : "Sound on", false, 2000); }
  function toggleCC() {
    ccOn = !ccOn;
    ccBtn.textContent = ccOn ? "CC: On" : "CC: Off";
    if (ccOn) post(active, "getTextTracks"); else post(active, "disableTextTrack");
    showHud(ccOn ? "Captions on" : "Captions off", false, 2000);
  }
  function togglePause() {
    if (state === "playing") {
      // use our own flag, not player events, so Resume always works even if an event was missed
      if (userPaused) {
        userPaused = false; paused = false; pauseBtn.textContent = "Pause";
        var my2 = token;
        post(active, "play"); showHud("Resumed", false, 2000);
        var sAct = active;
        [500, 1200].forEach(function (ms) { setTimeout(function () { if (my2 === token && state === "playing" && !userPaused) { pausedNow = null; post(active, "getPaused"); post(active, "setMuted", muted); post(active, "play"); } }, ms); });
        // verify; if the player still reports paused, reload it at the same position and play
        setTimeout(function () { post(sAct, "getPaused"); }, 1800);
        setTimeout(function () {
          if (my2 === token && state === "playing" && !userPaused && sAct === active && pausedNow === true) {
            showHud("Resume was ignored by the player - restarting it...", false, 4000);
            hardReload(sAct, lastSec);
          }
        }, 2400);
      } else {
        userPaused = true; paused = true; pauseBtn.textContent = "Resume";
        post(active, "pause"); showHud("Paused. Press Resume or Space to continue.", false, 3000);
      }
    } else if (state === "card") {
      holdCard = !holdCard;
      pauseBtn.textContent = holdCard ? "Resume" : "Pause";
      showHud(holdCard ? "Held on this card. Press Resume to start the demo." : "Starting...", false, 2500);
      if (!holdCard && pending) { var p = pending; pending = null; p(); }
    }
  }
  btn("◀ Previous", function () { goTo(idx - 1); showHud("Previous: " + V[idx].title, false, 2500); });
  btn("Pause", togglePause);
  pauseBtn = ctl.lastChild;
  btn("Next ▶", function () { goTo(idx + 1); showHud("Next: " + V[idx].title, false, 2500); });
  btn("Fullscreen", toggleFs);
  var soundBtn, ccBtn;
  btn(muted ? "Sound: Off" : "Sound: On", toggleSound);
  soundBtn = ctl.lastChild;
  btn(ccOn ? "CC: On" : "CC: Off", toggleCC);
  ccBtn = ctl.lastChild;
  strip.addEventListener("mousemove", function () { keepCtl(); });
  function keepCtl() {
    ctl.classList.add("vis");
    clearTimeout(ctlTimer);
    ctlTimer = setTimeout(function () { ctl.classList.remove("vis"); }, 4000);
  }
  ctl.addEventListener("mousemove", keepCtl);
  ctl.addEventListener("mouseenter", keepCtl);
  root.appendChild(strip);
  root.appendChild(ctl);
  document.addEventListener("keydown", function (e) {
    if (state === "idle") return;
    if (e.key === "ArrowRight") { goTo(idx + 1); showHud("Next: " + V[idx].title, false, 2500); }
    else if (e.key === "ArrowLeft") { goTo(idx - 1); showHud("Previous: " + V[idx].title, false, 2500); }
    else if (e.key === "m" || e.key === "M") toggleSound();
    else if (e.key === "c" || e.key === "C") toggleCC();
    else if (e.key === " ") { e.preventDefault(); togglePause(); }
  });

  var start = el("div", "fl-start",
    "<div style='font-size:28px;font-weight:600;color:#fff'>Demo Environment</div>" +
    (N > 0
      ? "<div>This runs Demos back to back, each introduced by a short Intro Slide.</div>"
      : "<div>No videos in the playlist yet.<br>Right-click the extension icon and choose <b>Options</b> to add Fortinet video URLs.</div>"));
  if (N > 0) {
    var sb = el("button", null, "Start");
    sb.onclick = function () {
      start.remove();
      if (root.requestFullscreen) root.requestFullscreen().catch(function () {});
      goTo(0);
    };
    start.appendChild(sb);
  }
  root.appendChild(start);

  window.__fl = function () {
    return { state: state, idx: idx, active: active, slotVideo: slotVideo.slice(), cardShown: card.classList.contains("show"), gotPlay: gotPlay, paused: paused, holdCard: holdCard, hud: hud.textContent, pauseLabel: pauseBtn && pauseBtn.textContent, log: window.__fl_log.slice() };
  };
})();
